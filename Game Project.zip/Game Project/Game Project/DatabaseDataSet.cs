﻿namespace Game_Project
{


    partial class DatabaseDataSet
    {
    }
}

namespace Game_Project.DatabaseDataSetTableAdapters {
    
    
    public partial class UserDataTableAdapter {
    }
}
