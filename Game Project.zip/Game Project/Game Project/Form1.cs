﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace Project_Design
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void loginCheck()
        {
            string username = textBoxUsername.Text;
            string password = textBoxPassword.Text;
            int Pin = Int32.Parse(textBoxPin.Text);
            var userDataTest = userDataTableAdapter.CheckLoginData(username,password);
            if (userDataTest.Rows.Count > 0)
            {
                pinCheck(username,password);
            }
            else
            {
                successLabel.Text = ("Login Unsuccessful - Please Try Again");
            }
        }

        private void loginSuccess()
        {
            successLabel.Text = ("Login Successful - Please Wait");
            successLabel.Visible = true;
            DateTime start = DateTime.Now;
            while ((DateTime.Now - start).TotalMilliseconds < 1000)
                Application.DoEvents();
            this.Visible = false;
            Form3 form3 = new Form3();
            form3.Visible = true;
        }

        private void pinCheck(string username, string password)
        {
            //int SP = Convert.ToInt32(userDataTableAdapter.GetPin(username,password));
            //labelGameTitle.Text = SP.ToString();
            string CS = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security=True";
            string Query = "SELECT pin FROM UserData WHERE(username = @username) AND(password = @password)";
            SqlConnection conDataBase = new SqlConnection(CS);
            SqlCommand cmdDataBase = new SqlCommand(Query, conDataBase);
            cmdDataBase.Parameters.AddWithValue("@username", username);
            cmdDataBase.Parameters.AddWithValue("@password", password);
            SqlDataReader myReader;
            try
            {
                labelGameTitle.Text = ();
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();
                MessageBox.Show("Y");
                while (myReader.Read())
                {
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
            //object username = userDataTableAdapter1.GetData()[0][0];
        }


        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void buttonMove1_Click(object sender, EventArgs e)
        {
            loginCheck();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
