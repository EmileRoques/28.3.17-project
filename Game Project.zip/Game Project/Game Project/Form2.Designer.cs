﻿namespace Project_Design
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.buttonMove1 = new System.Windows.Forms.Button();
            this.buttonMove2 = new System.Windows.Forms.Button();
            this.buttonMove3 = new System.Windows.Forms.Button();
            this.buttonMove4 = new System.Windows.Forms.Button();
            this.buttonSpecial = new System.Windows.Forms.Button();
            this.buttonItem = new System.Windows.Forms.Button();
            this.buttonArmour = new System.Windows.Forms.Button();
            this.buttonWeapon = new System.Windows.Forms.Button();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.labelName = new System.Windows.Forms.Label();
            this.labelStamina = new System.Windows.Forms.Label();
            this.labelGold = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBoxMain = new System.Windows.Forms.TextBox();
            this.labelNameValue = new System.Windows.Forms.Label();
            this.labelStaminaValue = new System.Windows.Forms.Label();
            this.labelGoldValue = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // buttonMove1
            // 
            this.buttonMove1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(184)))), ((int)(((byte)(152)))));
            this.buttonMove1.Font = new System.Drawing.Font("Gentium Basic", 14.25F, System.Drawing.FontStyle.Bold);
            this.buttonMove1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(54)))), ((int)(((byte)(59)))));
            this.buttonMove1.Location = new System.Drawing.Point(11, 230);
            this.buttonMove1.Margin = new System.Windows.Forms.Padding(0);
            this.buttonMove1.Name = "buttonMove1";
            this.buttonMove1.Size = new System.Drawing.Size(90, 38);
            this.buttonMove1.TabIndex = 3;
            this.buttonMove1.Text = "Move 1";
            this.buttonMove1.UseVisualStyleBackColor = false;
            this.buttonMove1.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonMove2
            // 
            this.buttonMove2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(184)))), ((int)(((byte)(152)))));
            this.buttonMove2.Font = new System.Drawing.Font("Gentium Basic", 14.25F, System.Drawing.FontStyle.Bold);
            this.buttonMove2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(54)))), ((int)(((byte)(59)))));
            this.buttonMove2.Location = new System.Drawing.Point(110, 230);
            this.buttonMove2.Margin = new System.Windows.Forms.Padding(0);
            this.buttonMove2.Name = "buttonMove2";
            this.buttonMove2.Size = new System.Drawing.Size(90, 38);
            this.buttonMove2.TabIndex = 4;
            this.buttonMove2.Text = "Move 2";
            this.buttonMove2.UseVisualStyleBackColor = false;
            this.buttonMove2.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonMove3
            // 
            this.buttonMove3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(184)))), ((int)(((byte)(152)))));
            this.buttonMove3.Font = new System.Drawing.Font("Gentium Basic", 14.25F, System.Drawing.FontStyle.Bold);
            this.buttonMove3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(54)))), ((int)(((byte)(59)))));
            this.buttonMove3.Location = new System.Drawing.Point(209, 230);
            this.buttonMove3.Margin = new System.Windows.Forms.Padding(0);
            this.buttonMove3.Name = "buttonMove3";
            this.buttonMove3.Size = new System.Drawing.Size(90, 38);
            this.buttonMove3.TabIndex = 5;
            this.buttonMove3.Text = "Move 3";
            this.buttonMove3.UseVisualStyleBackColor = false;
            this.buttonMove3.Click += new System.EventHandler(this.button3_Click);
            // 
            // buttonMove4
            // 
            this.buttonMove4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(184)))), ((int)(((byte)(152)))));
            this.buttonMove4.Font = new System.Drawing.Font("Gentium Basic", 14.25F, System.Drawing.FontStyle.Bold);
            this.buttonMove4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(54)))), ((int)(((byte)(59)))));
            this.buttonMove4.Location = new System.Drawing.Point(311, 230);
            this.buttonMove4.Margin = new System.Windows.Forms.Padding(0);
            this.buttonMove4.Name = "buttonMove4";
            this.buttonMove4.Size = new System.Drawing.Size(90, 38);
            this.buttonMove4.TabIndex = 6;
            this.buttonMove4.Text = "Move 4";
            this.buttonMove4.UseVisualStyleBackColor = false;
            this.buttonMove4.Click += new System.EventHandler(this.button4_Click);
            // 
            // buttonSpecial
            // 
            this.buttonSpecial.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(184)))), ((int)(((byte)(152)))));
            this.buttonSpecial.Font = new System.Drawing.Font("Gentium Basic", 14.25F, System.Drawing.FontStyle.Bold);
            this.buttonSpecial.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(54)))), ((int)(((byte)(59)))));
            this.buttonSpecial.Location = new System.Drawing.Point(11, 291);
            this.buttonSpecial.Margin = new System.Windows.Forms.Padding(0);
            this.buttonSpecial.Name = "buttonSpecial";
            this.buttonSpecial.Size = new System.Drawing.Size(390, 38);
            this.buttonSpecial.TabIndex = 7;
            this.buttonSpecial.Text = "Special";
            this.buttonSpecial.UseVisualStyleBackColor = false;
            // 
            // buttonItem
            // 
            this.buttonItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(184)))), ((int)(((byte)(152)))));
            this.buttonItem.Font = new System.Drawing.Font("Gentium Basic", 14.25F, System.Drawing.FontStyle.Bold);
            this.buttonItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(54)))), ((int)(((byte)(59)))));
            this.buttonItem.Location = new System.Drawing.Point(145, 350);
            this.buttonItem.Margin = new System.Windows.Forms.Padding(0);
            this.buttonItem.Name = "buttonItem";
            this.buttonItem.Size = new System.Drawing.Size(122, 38);
            this.buttonItem.TabIndex = 9;
            this.buttonItem.Text = "Item";
            this.buttonItem.UseVisualStyleBackColor = false;
            this.buttonItem.Click += new System.EventHandler(this.button8_Click);
            // 
            // buttonArmour
            // 
            this.buttonArmour.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(184)))), ((int)(((byte)(152)))));
            this.buttonArmour.Font = new System.Drawing.Font("Gentium Basic", 14.25F, System.Drawing.FontStyle.Bold);
            this.buttonArmour.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(54)))), ((int)(((byte)(59)))));
            this.buttonArmour.Location = new System.Drawing.Point(275, 350);
            this.buttonArmour.Margin = new System.Windows.Forms.Padding(0);
            this.buttonArmour.Name = "buttonArmour";
            this.buttonArmour.Size = new System.Drawing.Size(126, 38);
            this.buttonArmour.TabIndex = 10;
            this.buttonArmour.Text = "Armour";
            this.buttonArmour.UseVisualStyleBackColor = false;
            // 
            // buttonWeapon
            // 
            this.buttonWeapon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(184)))), ((int)(((byte)(152)))));
            this.buttonWeapon.Font = new System.Drawing.Font("Gentium Basic", 14.25F, System.Drawing.FontStyle.Bold);
            this.buttonWeapon.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(54)))), ((int)(((byte)(59)))));
            this.buttonWeapon.Location = new System.Drawing.Point(11, 350);
            this.buttonWeapon.Margin = new System.Windows.Forms.Padding(0);
            this.buttonWeapon.Name = "buttonWeapon";
            this.buttonWeapon.Size = new System.Drawing.Size(126, 38);
            this.buttonWeapon.TabIndex = 11;
            this.buttonWeapon.Text = "Weapon";
            this.buttonWeapon.UseVisualStyleBackColor = false;
            this.buttonWeapon.Click += new System.EventHandler(this.button9_Click);
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.BackColor = System.Drawing.Color.Transparent;
            this.labelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(184)))), ((int)(((byte)(152)))));
            this.labelName.Location = new System.Drawing.Point(23, 427);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(55, 20);
            this.labelName.TabIndex = 12;
            this.labelName.Text = "Name:";
            // 
            // labelStamina
            // 
            this.labelStamina.AutoSize = true;
            this.labelStamina.BackColor = System.Drawing.Color.Transparent;
            this.labelStamina.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStamina.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(184)))), ((int)(((byte)(152)))));
            this.labelStamina.Location = new System.Drawing.Point(7, 462);
            this.labelStamina.Name = "labelStamina";
            this.labelStamina.Size = new System.Drawing.Size(72, 20);
            this.labelStamina.TabIndex = 13;
            this.labelStamina.Text = "Stamina:";
            // 
            // labelGold
            // 
            this.labelGold.AutoSize = true;
            this.labelGold.BackColor = System.Drawing.Color.Transparent;
            this.labelGold.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGold.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(184)))), ((int)(((byte)(152)))));
            this.labelGold.Location = new System.Drawing.Point(19, 493);
            this.labelGold.Name = "labelGold";
            this.labelGold.Size = new System.Drawing.Size(60, 20);
            this.labelGold.TabIndex = 14;
            this.labelGold.Text = "Health:";
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.textBoxMain);
            this.panel1.Controls.Add(this.labelNameValue);
            this.panel1.Controls.Add(this.labelStaminaValue);
            this.panel1.Controls.Add(this.labelGoldValue);
            this.panel1.Controls.Add(this.buttonSpecial);
            this.panel1.Controls.Add(this.buttonMove1);
            this.panel1.Controls.Add(this.buttonMove2);
            this.panel1.Controls.Add(this.labelGold);
            this.panel1.Controls.Add(this.buttonMove3);
            this.panel1.Controls.Add(this.labelStamina);
            this.panel1.Controls.Add(this.buttonMove4);
            this.panel1.Controls.Add(this.labelName);
            this.panel1.Controls.Add(this.buttonArmour);
            this.panel1.Controls.Add(this.buttonItem);
            this.panel1.Controls.Add(this.buttonWeapon);
            this.panel1.ForeColor = System.Drawing.Color.Coral;
            this.panel1.Location = new System.Drawing.Point(90, 30);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(412, 535);
            this.panel1.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(184)))), ((int)(((byte)(152)))));
            this.label3.Location = new System.Drawing.Point(164, 493);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 20);
            this.label3.TabIndex = 22;
            this.label3.Text = "100";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(184)))), ((int)(((byte)(152)))));
            this.label2.Location = new System.Drawing.Point(164, 462);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 20);
            this.label2.TabIndex = 21;
            this.label2.Text = "100";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(184)))), ((int)(((byte)(152)))));
            this.label1.Location = new System.Drawing.Point(164, 427);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 20);
            this.label1.TabIndex = 20;
            this.label1.Text = "Boss";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(132)))), ((int)(((byte)(124)))));
            this.button1.Font = new System.Drawing.Font("Gentium Basic", 14.25F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(206)))), ((int)(((byte)(168)))));
            this.button1.Location = new System.Drawing.Point(271, 484);
            this.button1.Margin = new System.Windows.Forms.Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(130, 38);
            this.button1.TabIndex = 19;
            this.button1.Text = "Give Up";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // textBoxMain
            // 
            this.textBoxMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(206)))), ((int)(((byte)(168)))));
            this.textBoxMain.Font = new System.Drawing.Font("Gentium Basic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMain.Location = new System.Drawing.Point(11, 14);
            this.textBoxMain.Multiline = true;
            this.textBoxMain.Name = "textBoxMain";
            this.textBoxMain.Size = new System.Drawing.Size(390, 189);
            this.textBoxMain.TabIndex = 18;
            // 
            // labelNameValue
            // 
            this.labelNameValue.AutoSize = true;
            this.labelNameValue.BackColor = System.Drawing.Color.Transparent;
            this.labelNameValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNameValue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(184)))), ((int)(((byte)(152)))));
            this.labelNameValue.Location = new System.Drawing.Point(88, 427);
            this.labelNameValue.Name = "labelNameValue";
            this.labelNameValue.Size = new System.Drawing.Size(61, 20);
            this.labelNameValue.TabIndex = 17;
            this.labelNameValue.Text = "Player1";
            // 
            // labelStaminaValue
            // 
            this.labelStaminaValue.AutoSize = true;
            this.labelStaminaValue.BackColor = System.Drawing.Color.Transparent;
            this.labelStaminaValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStaminaValue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(184)))), ((int)(((byte)(152)))));
            this.labelStaminaValue.Location = new System.Drawing.Point(88, 462);
            this.labelStaminaValue.Name = "labelStaminaValue";
            this.labelStaminaValue.Size = new System.Drawing.Size(36, 20);
            this.labelStaminaValue.TabIndex = 16;
            this.labelStaminaValue.Text = "100";
            // 
            // labelGoldValue
            // 
            this.labelGoldValue.AutoSize = true;
            this.labelGoldValue.BackColor = System.Drawing.Color.Transparent;
            this.labelGoldValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGoldValue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(184)))), ((int)(((byte)(152)))));
            this.labelGoldValue.Location = new System.Drawing.Point(88, 493);
            this.labelGoldValue.Name = "labelGoldValue";
            this.labelGoldValue.Size = new System.Drawing.Size(36, 20);
            this.labelGoldValue.TabIndex = 15;
            this.labelGoldValue.Text = "100";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(598, 598);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(184)))), ((int)(((byte)(152)))));
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Button buttonMove1;
        private System.Windows.Forms.Button buttonMove2;
        private System.Windows.Forms.Button buttonMove3;
        private System.Windows.Forms.Button buttonMove4;
        private System.Windows.Forms.Button buttonSpecial;
        private System.Windows.Forms.Button buttonItem;
        private System.Windows.Forms.Button buttonArmour;
        private System.Windows.Forms.Button buttonWeapon;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelStamina;
        private System.Windows.Forms.Label labelGold;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBoxMain;
        private System.Windows.Forms.Label labelNameValue;
        private System.Windows.Forms.Label labelStaminaValue;
        private System.Windows.Forms.Label labelGoldValue;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}